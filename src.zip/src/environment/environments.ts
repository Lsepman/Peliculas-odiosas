export const environment = {
  production: false
};
export const URL_BASE = 'http://143.47.34.120/app.radfpd.es';
export const URL_API = `${URL_BASE}/api/private`;
