export const ERROR = 'Ocurrió un fallo';
export const CLOSE = 'Cerrar';
export const INVALID_FORM = 'El formulario no es válido';
