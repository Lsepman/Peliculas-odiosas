import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from 'src/app/shared/common.service';
import { URL_API } from "src/environment/environments";

const ENDPOINT = 'favorito';

@Injectable({
  providedIn: 'root'
})
export class FavoritaService {


  favoritos: number[] = [];
  existeUsuario: boolean = false;

  constructor(private http: HttpClient, private commonService: CommonService, private snackBar: MatSnackBar){}

    /**
   * Obtiene los headers con el token del usuario desde localStorage.
   */
    private getHeaders(): HttpHeaders {
      const token = localStorage.getItem('token'); // Obtener el token del usuario
      return new HttpHeaders({
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      });
    }

      /**
   * Carga las películas favoritas del usuario desde el backend con el token.
   */
  cargarFavoritos(): void {
    this.http.get<{ ok: boolean, data: number[] }>(
      `${URL_API}/favoritos.php`,
      { headers: this.getHeaders() }
    ).subscribe(response => {
      if (response.ok) {
        this.favoritos = response.data; // Guarda los favoritos en el array local
      }
    });
  }

    /**
   * Devuelve el array local de favoritos sin hacer una petición al backend.
   */
    getFavoritos(): number[] {
      return this.favoritos;
    }

    /**
     * Agrega una película a favoritos y sincroniza con el backend.
     */
    addFavorito(id_pelicula: number): void {
      if (!this.favoritos.includes(id_pelicula)) {
        this.favoritos.push(id_pelicula); // Agrega al array local

        this.http.post(
          `${URL_API}/favoritos.php`,
          { id_pelicula },
          { headers: this.getHeaders() }
        ).subscribe(response => {
          this.showSnackbar('Película agregada a favoritos');
        });
      }
    }

    /**
     * Elimina una película de favoritos y sincroniza con el backend.
     */
    removeFavorito(id_pelicula: number): void {
      this.favoritos = this.favoritos.filter(id => id !== id_pelicula); // Elimina del array local

      this.http.request('DELETE', `${URL_API}/favoritos.php`, {
        headers: this.getHeaders(),
        body: JSON.stringify({ id_pelicula }) // 🔹 Importante: Enviar como JSON
      }).subscribe(response => {
        this.showSnackbar('Película eliminada de favoritos');
      });
    }

    /**
     * Muestra una notificación tipo snackbar.
     */
    showSnackbar(message: string, action: string = 'Cerrar'): void {
      this.snackBar.open(message, action, { duration: 3000 });
    }
  }



