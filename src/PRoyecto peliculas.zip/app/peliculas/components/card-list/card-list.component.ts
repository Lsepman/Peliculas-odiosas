import { Component, Input, OnInit } from '@angular/core';
import { Pelicula } from '../../../interfaces/pelicula.interface';

import { PeliculasService } from '../../services/pelicula.service';
import { Genre } from '../../../interfaces/detalles.interface';
import { FavoritaService } from '../../services/favorita.service';


@Component({
  selector: 'pelicula-card-list',
  templateUrl: './card-list.component.html',
  styleUrls: ['./card-list.component.css']
})
export class CardListComponent implements OnInit{

  @Input()
  public pelicula!: Pelicula;

  public listaGenres: Genre[] = [];
  esFavorita: boolean = false;

  constructor(private peliculaService: PeliculasService, private favoritaService: FavoritaService){}

 ngOnInit(): void {
   this.listaGenres = this.peliculaService.listadoGenre.filter((genero) =>  this.pelicula.genre_ids.includes(genero.id));
  this.comprobarFavorita();
   }


 comprobarFavorita(): void {
  const favoritas = this.favoritaService.getFavoritos();
  this.esFavorita = favoritas.includes(this.pelicula.id);
 }

 addFavoriteFilm(): void {
  this.favoritaService.addFavorito(this.pelicula.id);
  this.esFavorita = true; // 🔹 Actualizamos la variable para ocultar el botón
}
deleteFavorites(): void {
  this.favoritaService.removeFavorito(this.pelicula.id);
  this.esFavorita = false; // 🔹 Actualizamos la variable para mostrar el botón de añadir
}


}


