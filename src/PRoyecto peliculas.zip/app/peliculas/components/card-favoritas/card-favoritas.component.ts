import { Component, Input, OnInit } from '@angular/core';
import { Detalles } from 'src/app/interfaces/detalles.interface';
import { PeliculasService } from '../../services/pelicula.service';
import { FavoritaService } from '../../services/favorita.service';

@Component({
  selector: 'app-card-favoritas',
  templateUrl: './card-favoritas.component.html',
  styleUrls: ['./card-favoritas.component.css']
})
export class CardFavoritasComponent implements OnInit {

  @Input() public favorita! : number;

  public pelicula: Detalles | null = null;

  constructor(private peliculaService: PeliculasService, private favoritaService: FavoritaService){}


  ngOnInit(): void {
    this.cargarDetallesPelicula()
  }

  cargarDetallesPelicula(): void {
    this.peliculaService.getPeliculasById(this.favorita).subscribe(response => {
      this.pelicula = response;
    });
  }

    /**
   * Elimina la película de favoritos.
   */
    eliminarFavorita(id_pelicula: number): void {
      this.favoritaService.removeFavorito(id_pelicula);
    }
  }

