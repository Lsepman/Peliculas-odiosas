import { Component, OnInit } from '@angular/core';
import { FavoritaService } from '../../services/favorita.service';

@Component({
  selector: 'app-favoritos-page',
  templateUrl: './favoritos-page.component.html',
  styles: [
  ]
})
export class FavoritosPageComponent implements OnInit{

  favoritas: number[] = [];
  
  constructor(private favoritaService: FavoritaService){}


  ngOnInit(): void {
    this.favoritaService.cargarFavoritos();
    this.favoritas= this.favoritaService.getFavoritos();
  }

  agregarFavorita(id: number) :void{
    this.favoritaService.addFavorito(id);
    this.favoritas = this.favoritaService.getFavoritos();
  }

  eliminarFavorita(id:number): void{
    this.favoritaService.removeFavorito(id);
    this.favoritas = this.favoritaService.getFavoritos();
  }




}
