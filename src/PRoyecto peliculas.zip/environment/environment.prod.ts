export const environment = {
  production: true
};
export const URL_API = 'https://143.47.34.120/app.radfpd.es';
export const URL_BASE = 'https://app.radfpd.es';
